package FileSystem;

import java.util.ArrayList;
public class Screens {

    public static void main(){
        Screens view = new Screens();
        System.out.println();
        view.WelcomeString();
    }
    public void WelcomeString(){
        int count = 20;
        String productName = "*!*!*!*!*!*!*!*!*!* PRESENTING YOU APPLICATION LOCKEDME.COM BY LOCKERS PVT.LTD. *!*!*!*!*!*!*!*!*!*";
        String developerName = "\t\t\t\t\tDeveloped By -> KARTIK DIXIT";
        System.out.println();
        System.out.println(productName);
        System.out.println(developerName);
        System.out.println("=================================================================================");
        System.out.println();

    }
}